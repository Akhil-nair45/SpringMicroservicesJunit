package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Dto.Login;
import com.example.demo.Model.User;
import com.example.demo.Repository.UserRepo;

@RestController
public class LoginController {

	@Autowired
	private UserRepo ur;
	
	@PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Login login) {
        User user = ur.findByName(login.getName());
        
        if (user == null) {
            // User not found
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password");
        }
        
        if (!user.getPassword().equals(login.getPassword())) {
            // Invalid password
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password");
        }
        
        // Successful login
        return ResponseEntity.ok().body("Login successful");
    }
}

